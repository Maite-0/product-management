<x-layout>
    <h1 class='title'>Hello {{auth()->user()->username}}</h1>
</x-layout>