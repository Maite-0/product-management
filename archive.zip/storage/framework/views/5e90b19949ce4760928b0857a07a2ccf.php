<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?php echo e(env('APP_NAME')); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        
        <!-- Scripts and CSS import -->
    </head> 
    <body>
        <Header>
            <nav>
                <h1 class="text-4xl">Nav</h1> 
            </nav>
        </Header>
        <main>
            <?php echo $__env->yieldContent('main'); ?>
        </main>
    </body>       
</html>
<?php /**PATH /home/ubuntu/Documents/PhpProjects/assesment-task/resources/views/layout.blade.php ENDPATH**/ ?>